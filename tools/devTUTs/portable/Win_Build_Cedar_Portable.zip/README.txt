1) Install Visual Studio 2019 (e.g. community edition, select c++ modules)
2) Install Git for Windows (select git from the command line...)
3) Download https://github.com/indygreg/python-build-standalone/releases/download/20200517/cpython-3.7.7-x86_64-pc-windows-msvc-shared-pgo-20200517T2128.tar.zst (needs to be decompressed under linux)
If you dont want to compile with PythonQT, leave 1B out and set CEDAR_USE_PYTHONSCRIPTSTEP in cedar.conf to 0.
4) Run all *.bat files (1 then, 1B, 2 and finaly 3) in the "x64 Native Tools Command Prompt for VS 2019"
5) zip the dist dir